"use strict";

require("./src/patchWs"); // phai nap TRUOC ws3-fca de va loi subprotocol cua MQTT

const fs = require("fs");
const path = require("path");
const { login } = require("./src/bot");
const { GameManager } = require("./src/gameManager");

const ROOT = __dirname;

function loadConfig() {
  const p = path.resolve(ROOT, "config.json");
  if (!fs.existsSync(p)) {
    console.error(
      "\n[LOI] Chua co config.json.\n" +
        "Hay copy config.example.json thanh config.json roi dien thong tin dang nhap.\n"
    );
    process.exit(1);
  }
  const cfg = JSON.parse(fs.readFileSync(p, "utf8"));
  // gia tri mac dinh phong khi thieu
  cfg.prefix = cfg.prefix || "!";
  cfg.game = cfg.game || {};
  cfg.game.minPlayers = cfg.game.minPlayers || 6;
  cfg.game.maxPlayers = cfg.game.maxPlayers || 50;
  cfg.game.noiTu = Object.assign({ turnSeconds: 40, strictDictionary: false }, cfg.game.noiTu);
  cfg.game.maSoi = Object.assign(
    { joinSeconds: 90, nightSeconds: 60, daySeconds: 120, voteSeconds: 60 },
    cfg.game.maSoi
  );
  return cfg;
}

async function main() {
  const config = loadConfig();
  console.log("Dang dang nhap Facebook...");

  let api;
  try {
    api = await login(config, ROOT);
  } catch (e) {
    console.error("\n[LOI DANG NHAP]", e.message || e);
    console.error(
      "Meo: neu tai khoan bat 2FA hoac bi chan, hay dung appstate (xem HUONG_DAN.md)."
    );
    process.exit(1);
  }

  const me = api.getCurrentUserID();
  console.log(`Dang nhap thanh cong. UID bot: ${me}`);
  console.log(`Prefix lenh: "${config.prefix}"  |  Go ${config.prefix}help trong nhom de bat dau.`);

  const manager = new GameManager(api, config);

  api.listenMqtt(async (err, event) => {
    if (err) {
      console.error("[listen] loi:", err);
      return;
    }
    try {
      await manager.onMessage(event);
    } catch (e) {
      console.error("[xu ly su kien] loi:", e);
    }
  });

  // Giu tien trinh song + xu ly tat may
  process.on("SIGINT", () => {
    console.log("\nDang tat bot...");
    process.exit(0);
  });
  process.on("unhandledRejection", (r) => console.error("[unhandledRejection]", r));
}

main();
