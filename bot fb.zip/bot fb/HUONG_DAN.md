# Hướng dẫn cài đặt & chạy bot

> ⚠️ **ĐỌC KỸ TRƯỚC KHI DÙNG**
> Bot này đăng nhập như **một người dùng Facebook thật** (dùng thư viện không
> chính thức) vì API chính thức của Facebook **không cho bot vào nhóm chat cá nhân**.
> Việc này **vi phạm Điều khoản của Facebook và có thể bị KHÓA tài khoản**.
> 👉 **Hãy dùng một tài khoản phụ (nick clone), ĐỪNG dùng tài khoản chính của bạn.**

---

## 1. Cài đặt

Cần có [Node.js](https://nodejs.org) (bản 18 trở lên — máy bạn đang có v24, OK).

Mở PowerShell tại thư mục dự án rồi chạy:

```bash
npm install
```

## 2. Tạo file cấu hình

Copy file mẫu thành `config.json`:

```bash
copy config.example.json config.json
```

(File `config.json` đã được tạo sẵn cho bạn, chỉ cần mở ra điền.)

## 3. Đăng nhập

### Cách A — Đăng nhập qua web (MẶC ĐỊNH, khuyên dùng) ✅

Trong `config.json` để `"loginMethod": "web"` (đã đặt sẵn). Chạy:

```bash
npm run login
```

Bot sẽ **tự mở cửa sổ Chrome/Edge** vào trang Facebook. Bạn **đăng nhập bằng tay**
ngay trên đó (tự nhập mật khẩu, xử lý 2FA/xác minh như bình thường). Đăng nhập
xong, bot **tự lấy cookie phiên** và lưu thành `appstate.json`, rồi đóng trình duyệt.

- Bạn **không cần** điền mật khẩu vào file config — bot không hề đọc mật khẩu của bạn.
- Lần sau khỏi đăng nhập lại (đã có `appstate.json`). Muốn đổi tài khoản: xoá
  `appstate.json` rồi chạy lại `npm run login`.
- Nếu máy không có Chrome/Edge ở vị trí mặc định, điền đường dẫn `chrome.exe`
  vào `"browserPath"` trong `config.json`.

> Bạn cũng có thể bỏ qua bước này: chỉ cần `npm start`, nếu chưa có `appstate.json`
> bot sẽ tự mở web cho bạn đăng nhập rồi chạy tiếp luôn.

### Cách B — Dán cookie thủ công

Nếu muốn tự lấy cookie: cài tiện ích **C3C FBState** (Chrome/Edge), đăng nhập
tài khoản phụ, export JSON, dán vào file `appstate.json` cạnh `index.js`.

### Cách C — Email + mật khẩu

Đặt `"loginMethod": "password"`, điền `email` + `password`. Tài khoản **không
được bật 2FA** (nếu bật thì dùng Cách A).

## 4. Chạy bot

```bash
npm start
```

Lần đầu chưa có `appstate.json` thì bot sẽ mở web cho bạn đăng nhập trước.
Khi thấy dòng `Đăng nhập thành công. UID bot: ...` là bot đã sẵn sàng.
Thêm tài khoản bot vào nhóm chat Messenger, rồi trong nhóm gõ:

```
!help
```

---

## 5. Cách chơi trong nhóm

| Lệnh | Ý nghĩa |
|------|---------|
| `!noitu` | Mở một ván Nối Từ |
| `!masoi` | Mở một ván Ma Sói |
| `!join` | Tham gia ván đang mở |
| `!leave` | Rời ván |
| `!players` | Xem danh sách người chơi |
| `!start` | Chủ phòng bắt đầu (cần ≥ 6 người) |
| `!cancel` | Huỷ ván (chủ phòng) |
| `!vote <số>` | Bỏ phiếu treo cổ (trong Ma Sói) |
| `!stop` | Dừng ván đang chạy (chủ phòng/admin) |
| `!help` | Xem trợ giúp |

**Số người:** tối thiểu **6**, tối đa **50** (đổi trong `config.json`).

### ⚠️ Ma Sói cần bot nhắn riêng được cho từng người
Bot phải gửi **tin nhắn riêng (DM)** để báo vai và nhận hành động ban đêm.
Muốn nhận được DM, mỗi người chơi **phải là bạn bè với tài khoản bot** hoặc đã
từng mở cuộc trò chuyện riêng với bot (nếu không, tin sẽ rơi vào *Tin nhắn chờ*).
👉 Mẹo: trước khi chơi, bảo mọi người nhắn "hi" cho nick bot một lần.

---

## 6. Câu hỏi thường gặp

**Bot bị đăng xuất / báo lỗi checkpoint?**
Facebook nghi ngờ đăng nhập lạ. Đăng nhập lại tài khoản trên trình duyệt cùng
thiết bị, xác minh, rồi lấy lại `appstate.json`. Dùng appstate ổn định hơn.

**`npm install` báo không tìm thấy `ws3-fca`?**
Thử đổi sang thư viện khác (ví dụ `fca-unofficial`): chạy `npm install fca-unofficial`
rồi chạy bot với `set FCA_MODULE=fca-unofficial && npm start` (PowerShell:
`$env:FCA_MODULE="fca-unofficial"; npm start`). Code đã tách riêng phần đăng
nhập nên chỉ cần thư viện có hàm `login` tương thích là chạy được.

**Về "giới hạn 1000 file":** mã nguồn của dự án chỉ khoảng 14 file. Thư mục
`node_modules` (thư viện tải về) mới chiếm nhiều file nhưng nó được tạo tự động
và đã cho vào `.gitignore` — bạn không cần đụng tới nó.

**Không muốn bị khoá tài khoản chính?** Luôn dùng nick phụ để làm bot.
