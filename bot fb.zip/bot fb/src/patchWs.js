"use strict";

/**
 * Va loi ket noi MQTT cua ws3-fca voi thu vien `ws` >= 8.
 *
 * Nguyen nhan: `ws3-fca` -> `websocket-stream` truyen `protocols = null` cho
 * WebSocket. Ban `ws` moi bien `null` thanh `[null]` roi coi `null` la mot
 * "subprotocol" khong hop le -> nem loi:
 *   "An invalid or duplicated subprotocol was specified".
 *
 * Cach sua: boc lai lop WebSocket, ep `protocols` null/khong hop le ve `[]`.
 * Phai nap file nay TRUOC khi ws3-fca (va websocket-stream) duoc nap.
 */
try {
  const wsPath = require.resolve("ws");
  const Original = require("ws");

  if (!Original.__patchedSubprotocol) {
    class PatchedWebSocket extends Original {
      constructor(address, protocols, options) {
        if (protocols == null) {
          protocols = [];
        } else if (Array.isArray(protocols)) {
          protocols = protocols.filter((p) => typeof p === "string" && p.length > 0);
        } else if (typeof protocols !== "string") {
          protocols = [];
        }
        super(address, protocols, options);
      }
    }

    // Sao chep cac thuoc tinh tinh (Server, Receiver, Sender, createWebSocketStream, ...)
    for (const k of Object.getOwnPropertyNames(Original)) {
      if (k === "length" || k === "name" || k === "prototype") continue;
      try {
        PatchedWebSocket[k] = Original[k];
      } catch (_) {}
    }
    PatchedWebSocket.WebSocket = PatchedWebSocket;
    PatchedWebSocket.__patchedSubprotocol = true;

    require.cache[wsPath].exports = PatchedWebSocket;
  }
} catch (e) {
  // Neu chua cai `ws` (chua npm install) thi bo qua - se bao loi ro rang o cho khac.
}
