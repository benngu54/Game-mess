"use strict";

/**
 * Dang nhap bang cach MO TRINH DUYET FACEBOOK THAT.
 *
 * Bot mo cua so Chrome/Edge (co san tren may), ban tu dang nhap bang tay
 * (tu xu ly 2FA, xac minh...). Sau khi dang nhap xong, bot doc cookie phien
 * dang nhap tu chinh trinh duyet do va luu thanh appstate.json.
 *
 * KHONG can nhap email/mat khau vao file config -> an toan hon.
 */

const fs = require("fs");
const path = require("path");
const os = require("os");

/** Tim duong dan Chrome hoac Edge co san tren Windows/macOS/Linux. */
function findBrowser(configPath) {
  if (configPath && fs.existsSync(configPath)) return configPath;

  const home = os.homedir();
  const candidates = [
    // Windows - Chrome
    "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "C:/Program Files (x86)/Google/Chrome/Application/chrome.exe",
    path.join(home, "AppData/Local/Google/Chrome/Application/chrome.exe"),
    // Windows - Edge
    "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
    "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
    // macOS
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    // Linux
    "/usr/bin/google-chrome",
    "/usr/bin/chromium-browser",
    "/usr/bin/chromium",
    "/usr/bin/microsoft-edge",
  ];
  for (const p of candidates) {
    try {
      if (fs.existsSync(p)) return p;
    } catch (_) {}
  }
  return null;
}

/** Chuyen cookie cua puppeteer sang dinh dang appstate ma FCA hieu. */
function toAppState(cookies) {
  const now = new Date().toISOString();
  return cookies
    .filter((c) => /facebook\.com$/.test((c.domain || "").replace(/^\./, "")))
    .map((c) => ({
      key: c.name,
      value: c.value,
      domain: c.domain.startsWith(".") ? c.domain : "." + c.domain,
      path: c.path || "/",
      hostOnly: false,
      creation: now,
      lastAccessed: now,
    }));
}

/**
 * Mo trinh duyet, cho nguoi dung dang nhap, roi tra ve appState (mang cookie).
 * @param {object} config
 * @param {string} rootDir
 * @returns {Promise<Array>} appState
 */
async function getAppStateViaWeb(config, rootDir) {
  let puppeteer;
  try {
    puppeteer = require("puppeteer-core");
  } catch (e) {
    throw new Error(
      "Chua cai puppeteer-core. Chay: npm install\n(Can de mo trinh duyet dang nhap web.)"
    );
  }

  const exe = findBrowser(config.browserPath);
  if (!exe) {
    throw new Error(
      "Khong tim thay Chrome/Edge tren may.\n" +
        'Hay cai Google Chrome, hoac dat "browserPath" trong config.json tro toi chrome.exe/msedge.exe.'
    );
  }

  // Luu ho so trinh duyet de lan sau khong phai dang nhap lai
  const userDataDir = path.resolve(rootDir, ".browser-profile");

  console.log("\nDang mo trinh duyet:", exe);
  console.log("👉 Hay dang nhap Facebook trong cua so vua mo. Bot se tu nhan khi xong.\n");

  const browser = await puppeteer.launch({
    executablePath: exe,
    headless: false,
    userDataDir,
    defaultViewport: null,
    args: ["--no-first-run", "--no-default-browser-check", "--start-maximized"],
  });

  try {
    const pages = await browser.pages();
    const page = pages[0] || (await browser.newPage());
    await page.goto("https://www.facebook.com/", { waitUntil: "domcontentloaded" });

    const client = await page.target().createCDPSession();

    const timeoutMs = (config.loginTimeoutSeconds || 300) * 1000;
    const start = Date.now();

    // Cho den khi co cookie "c_user" (dau hieu da dang nhap)
    let appState = null;
    while (Date.now() - start < timeoutMs) {
      let all;
      try {
        all = (await client.send("Network.getAllCookies")).cookies || [];
      } catch (_) {
        all = [];
      }
      const hasLogin = all.some((c) => c.name === "c_user" && c.value);
      if (hasLogin) {
        appState = toAppState(all);
        break;
      }
      // Neu nguoi dung dong cua so
      if (!browser.connected && !browser.isConnected) break;
      await new Promise((r) => setTimeout(r, 2000));
    }

    if (!appState) {
      throw new Error("Het thoi gian cho dang nhap (hoac ban dong cua so truoc khi xong).");
    }

    const out = path.resolve(rootDir, config.appStateFile || "appstate.json");
    fs.writeFileSync(out, JSON.stringify(appState, null, 2));
    console.log("✅ Da luu phien dang nhap vao:", out);
    return appState;
  } finally {
    try {
      await browser.close();
    } catch (_) {}
  }
}

module.exports = { getAppStateViaWeb, findBrowser };
