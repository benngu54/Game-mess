"use strict";

const { numberedList } = require("./utils/format");

const GAME_LABEL = {
  noitu: "Noi Tu (noi tu)",
  masoi: "Ma Soi (Werewolf)",
};

/**
 * Sanh cho (lobby): thu thap nguoi choi truoc khi bat dau van.
 */
class Lobby {
  constructor(ctx, type, hostID) {
    this.ctx = ctx;
    this.type = type; // 'noitu' | 'masoi'
    this.hostID = hostID;
    this.players = [hostID]; // chu phong tu dong tham gia
    this.min = ctx.config.game.minPlayers;
    this.max = ctx.config.game.maxPlayers;
    this.state = "waiting";
  }

  async announceOpen() {
    const host = await this.ctx.getName(this.hostID);
    await this.ctx.send(
      `🎮 ${host} vua mo van *${GAME_LABEL[this.type]}*!\n\n` +
        `👉 Go *${this.ctx.prefix}join* de tham gia.\n` +
        `Can it nhat *${this.min}* nguoi, toi da *${this.max}* nguoi.\n` +
        `Chu phong go *${this.ctx.prefix}start* khi du nguoi, hoac *${this.ctx.prefix}cancel* de huy.`
    );
  }

  isFull() {
    return this.players.length >= this.max;
  }

  has(userID) {
    return this.players.includes(userID);
  }

  async join(userID) {
    if (this.has(userID)) {
      return this.ctx.send("Ban da o trong danh sach roi nhe.");
    }
    if (this.isFull()) {
      return this.ctx.send(`Da du toi da ${this.max} nguoi, khong the tham gia them.`);
    }
    this.players.push(userID);
    const name = await this.ctx.getName(userID);
    await this.ctx.send(
      `✅ ${name} da tham gia! (${this.players.length}/${this.max})` +
        (this.players.length >= this.min
          ? `\nDa du nguoi. Chu phong co the go ${this.ctx.prefix}start.`
          : `\nCan them ${this.min - this.players.length} nguoi nua.`)
    );
  }

  async leave(userID) {
    if (!this.has(userID)) return;
    this.players = this.players.filter((id) => id !== userID);
    const name = await this.ctx.getName(userID);
    if (userID === this.hostID) {
      // Chu phong roi -> chuyen quyen hoac huy
      if (this.players.length === 0) {
        await this.ctx.send("Chu phong da roi, khong con ai. Huy van.");
        return this.ctx.finish();
      }
      this.hostID = this.players[0];
      const newHost = await this.ctx.getName(this.hostID);
      await this.ctx.send(`${name} (chu phong) da roi. ${newHost} tro thanh chu phong moi.`);
    } else {
      await this.ctx.send(`👋 ${name} da roi phong. (${this.players.length}/${this.max})`);
    }
  }

  async listPlayers() {
    const names = await this.ctx.getNames(this.players);
    await this.ctx.send(
      `👥 Danh sach (${this.players.length}/${this.max}):\n` +
        numberedList(this.players.map((id) => names[id]))
    );
  }

  async tryStart(userID, launch) {
    if (userID !== this.hostID) {
      return this.ctx.send("Chi chu phong moi duoc bat dau van.");
    }
    if (this.players.length < this.min) {
      return this.ctx.send(
        `Chua du nguoi. Can it nhat ${this.min}, hien co ${this.players.length}.`
      );
    }
    this.state = "starting";
    await this.ctx.send(`🚀 Bat dau van ${GAME_LABEL[this.type]} voi ${this.players.length} nguoi!`);
    launch(this.type, this.players.slice(), this.hostID);
  }

  async cancel(userID) {
    if (userID !== this.hostID && !this.ctx.isAdmin(userID)) {
      return this.ctx.send("Chi chu phong (hoac admin) moi duoc huy.");
    }
    await this.ctx.send("❌ Da huy van. Hen gap lai!");
    this.ctx.finish();
  }
}

module.exports = { Lobby, GAME_LABEL };
