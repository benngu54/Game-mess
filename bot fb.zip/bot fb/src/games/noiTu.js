"use strict";

const fs = require("fs");
const path = require("path");
const { normalize } = require("../utils/format");

let DICTIONARY = null;
let DICT_ARRAY = null;
function loadDictionary() {
  if (DICTIONARY) return DICTIONARY;
  DICTIONARY = new Set();
  try {
    const file = path.resolve(__dirname, "../../data/words.txt");
    const raw = fs.readFileSync(file, "utf8");
    for (const line of raw.split(/\r?\n/)) {
      const w = normalize(line);
      if (w && !w.startsWith("#") && w.split(" ").filter(Boolean).length === 2) DICTIONARY.add(w);
    }
  } catch (e) {
    console.warn("[NoiTu] Khong doc duoc data/words.txt:", e.message);
  }
  DICT_ARRAY = [...DICTIONARY];
  return DICTIONARY;
}

function syllables(phrase) {
  return normalize(phrase).split(" ").filter(Boolean);
}

// Vai tu mo dau du phong neu tu dien trong
const FALLBACK_SEEDS = ["học sinh", "gia đình", "mặt trời", "công việc", "tình yêu"];

/**
 * Game Noi Tu - CHE DO MO.
 * Ai trong nhom cung choi duoc, KHONG can join, KHONG gioi han so nguoi.
 * Bot ra mot tu mo dau; bat ky ai go duoc cum 2 tieng noi tiep hop le
 * (tieng dau = tieng cuoi cum hien tai, chua tung dung) la duoc tinh diem.
 * Go !stop de ket thuc va xem bang xep hang.
 */
class NoiTuGame {
  constructor(ctx, starterID) {
    this.ctx = ctx;
    this.cfg = ctx.config.game.noiTu;
    this.hostID = starterID; // nguoi mo van (dung cho quyen !stop)
    this.dict = loadDictionary();
    this.current = null; // cum hien tai
    this.required = null; // tieng ma cum tiep theo phai bat dau
    this.used = new Set();
    this.scores = new Map(); // userID -> so tu noi dung
    this.count = 0;
    this.ended = false;
  }

  pickSeed() {
    const pool = DICT_ARRAY && DICT_ARRAY.length ? DICT_ARRAY : FALLBACK_SEEDS;
    return pool[Math.floor(Math.random() * pool.length)];
  }

  async start() {
    this.current = this.pickSeed();
    this.used.add(this.current);
    this.required = syllables(this.current).slice(-1)[0];
    await this.ctx.send(
      `📝 *NOI TU - CHE DO MO!*\n` +
        `Ai cung choi duoc, khong can tham gia truoc, khong gioi han so nguoi.\n\n` +
        `Tu mo dau: *${this.current}*\n` +
        `👉 Go mot cum *2 tieng* bat dau bang *"${this.required}"* (chua ai dung).\n` +
        (this.cfg.strictDictionary ? "Che do: *bat buoc co trong tu dien*.\n" : "") +
        `Go *${this.ctx.prefix}stop* de ket thuc va xem bang xep hang.`
    );
  }

  /** Nhan MOI tin nhan nhom. Chi coi la nuoc di khi la cum 2 tieng dung "required". */
  async handleMessage(userID, text) {
    if (this.ended) return;
    const t = normalize(text);
    if (!t || t.startsWith(this.ctx.prefix)) return; // bo qua lenh
    const parts = t.split(" ").filter(Boolean);
    if (parts.length !== 2) return; // khong phai nuoc di -> coi la chat, bo qua
    if (parts[0] !== this.required) return; // khong bat dau dung tieng -> coi la chat, bo qua

    // Day la mot nuoc di that su (dung tieng dau)
    if (this.used.has(t)) {
      return this.ctx.send(`❗ "${t}" da duoc dung roi. Thu cum khac bat dau bang *"${this.required}"*.`);
    }
    if (this.cfg.strictDictionary && this.dict.size && !this.dict.has(t)) {
      return this.ctx.send(`❗ "${t}" khong co trong tu dien. Thu cum khac.`);
    }

    // Hop le
    this.used.add(t);
    this.current = t;
    this.required = parts[1];
    this.scores.set(userID, (this.scores.get(userID) || 0) + 1);
    this.count++;
    const name = await this.ctx.getName(userID);
    await this.ctx.send(`✔️ ${name}: *${t}*  →  tiep theo bat dau bang *"${this.required}"*`);
  }

  /** Ket thuc + hien bang xep hang. Goi tu !stop. */
  async stop() {
    if (this.ended) return;
    this.ended = true;
    const entries = [...this.scores.entries()].sort((a, b) => b[1] - a[1]);
    if (!entries.length) {
      await this.ctx.send("🏁 Ket thuc Noi Tu. Chua ai noi duoc tu nao.");
    } else {
      const names = await this.ctx.getNames(entries.map((e) => e[0]));
      const medals = ["🥇", "🥈", "🥉"];
      const board = entries
        .map((e, i) => `${medals[i] || i + 1 + "."} ${names[e[0]]}: ${e[1]} tu`)
        .join("\n");
      await this.ctx.send(
        `🏁 *Ket thuc Noi Tu!* Tong cong ${this.count} tu duoc noi.\n\n🏅 *Bang xep hang:*\n${board}`
      );
    }
    this.ctx.finish();
  }

  async forceStop() {
    this.ended = true;
  }
}

module.exports = { NoiTuGame };
