"use strict";

/**
 * Dinh nghia cac vai (role) trong Ma Soi.
 * team: 'soi' (phe soi) hoac 'dan' (phe dan lang).
 */
const ROLES = {
  SOI: {
    key: "SOI",
    name: "Soi (Ma Soi)",
    team: "soi",
    emoji: "🐺",
    desc:
      "Moi dem, phe Soi cung nhau chon MOT dan lang de can chet. " +
      "Ban ngay hay gia vo la dan lang de khong bi treo co.",
  },
  DAN: {
    key: "DAN",
    name: "Dan lang",
    team: "dan",
    emoji: "🧑‍🌾",
    desc:
      "Ban khong co phep dac biet. Ban ngay hay suy luan va bo phieu " +
      "treo co ke ma ban nghi la Soi.",
  },
  TIEN_TRI: {
    key: "TIEN_TRI",
    name: "Tien tri",
    team: "dan",
    emoji: "🔮",
    desc:
      "Moi dem ban duoc soi 1 nguoi de biet ho la Soi hay khong. " +
      "Hay giup dan lang tim ra bay Soi.",
  },
  BAO_VE: {
    key: "BAO_VE",
    name: "Bao ve",
    team: "dan",
    emoji: "🛡️",
    desc:
      "Moi dem ban chon bao ve 1 nguoi khoi bi Soi can. " +
      "Khong the bao ve cung 1 nguoi 2 dem lien tiep.",
  },
  PHU_THUY: {
    key: "PHU_THUY",
    name: "Phu thuy",
    team: "dan",
    emoji: "🧪",
    desc:
      "Ban co 1 binh CUU va 1 binh DOC (moi loai dung 1 lan ca van). " +
      "Ban dem, bot se cho biet ai sap chet de ban quyet dinh.",
  },
  THO_SAN: {
    key: "THO_SAN",
    name: "Tho san",
    team: "dan",
    emoji: "🏹",
    desc:
      "Khi ban chet (bi can hoac bi treo co), ban duoc ban chet " +
      "theo 1 nguoi bat ky.",
  },
};

/**
 * Chia vai theo so nguoi choi (6..50).
 * Tra ve mang cac key vai (chua tron), do dai = so nguoi choi.
 */
function buildRoleDeck(n) {
  const wolves = Math.max(1, Math.round(n / 5)); // ~20% la Soi
  const deck = [];

  for (let i = 0; i < wolves; i++) deck.push("SOI");

  // Cac vai dac biet phe dan (theo nguong so nguoi)
  const specials = [];
  specials.push("TIEN_TRI"); // luon co
  if (n >= 8) specials.push("BAO_VE");
  if (n >= 8) specials.push("PHU_THUY");
  if (n >= 10) specials.push("THO_SAN");

  for (const s of specials) {
    if (deck.length < n) deck.push(s);
  }

  // Con lai la dan lang
  while (deck.length < n) deck.push("DAN");

  return deck.slice(0, n);
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Gan vai cho tung nguoi choi. Tra ve Map<userID, roleKey>. */
function assignRoles(players) {
  const deck = shuffle(buildRoleDeck(players.length));
  const map = new Map();
  players.forEach((uid, i) => map.set(uid, deck[i]));
  return map;
}

module.exports = { ROLES, buildRoleDeck, assignRoles };
