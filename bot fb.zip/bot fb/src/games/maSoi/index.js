"use strict";

const { ROLES, assignRoles } = require("./roles");
const { normalize, numberedList } = require("../../utils/format");

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/**
 * Game Ma Soi (Werewolf) qua Messenger.
 * - Bot nhan tin RIENG (DM) cho tung nguoi de bao vai va nhan hanh dong dem.
 * - Cong khai trong nhom: thong bao ket qua, thao luan, bo phieu treo co.
 */
class MaSoiGame {
  constructor(ctx, players) {
    this.ctx = ctx;
    this.cfg = ctx.config.game.maSoi;
    this.players = players.slice();
    this.roleOf = assignRoles(this.players); // Map<uid, roleKey>
    this.alive = new Set(this.players);
    this.pendingDM = new Map(); // uid -> fn(text)
    this.phase = "idle";
    this.round = 0;
    this.ended = false;

    // trang thai dac biet
    this.lastGuarded = null; // bao ve khong lap 2 dem
    this.witchHealUsed = false;
    this.witchPoisonUsed = false;
    this.votes = new Map(); // uid_voter -> uid_target (trong luot vote)
  }

  role(uid) {
    return ROLES[this.roleOf.get(uid)];
  }
  isWolf(uid) {
    return this.role(uid).team === "soi";
  }
  aliveList() {
    return this.players.filter((id) => this.alive.has(id));
  }
  aliveWolves() {
    return this.aliveList().filter((id) => this.isWolf(id));
  }
  aliveVillagers() {
    return this.aliveList().filter((id) => !this.isWolf(id));
  }
  playersWithRole(key) {
    return this.aliveList().filter((id) => this.roleOf.get(id) === key);
  }

  // ---- Dinh tuyen DM tu manager ----
  handleDM(userID, text) {
    const fn = this.pendingDM.get(userID);
    if (fn) fn(text);
  }

  /**
   * Gui menu DM va cho nguoi choi tra loi 1 con so hop le.
   * @returns {Promise<string|null>} userID muc tieu, hoac null neu het gio.
   */
  awaitChoice(userID, targets, promptText, seconds) {
    return new Promise(async (resolve) => {
      if (!targets.length) return resolve(null);
      const names = await this.ctx.getNames(targets);
      const menu = numberedList(targets.map((id) => names[id]));
      await this.ctx.sendDM(userID, `${promptText}\n${menu}\n\n(Nhan so trong ${seconds}s)`);

      let done = false;
      const finish = (val) => {
        if (done) return;
        done = true;
        this.pendingDM.delete(userID);
        clearTimeout(timer);
        resolve(val);
      };
      const timer = setTimeout(() => {
        this.ctx.sendDM(userID, "⏰ Het gio, ban khong hanh dong dem nay.");
        finish(null);
      }, seconds * 1000);

      this.pendingDM.set(userID, (text) => {
        const n = parseInt(normalize(text), 10);
        if (!n || n < 1 || n > targets.length) {
          this.ctx.sendDM(userID, `Nhap so tu 1 den ${targets.length} nhe.`);
          return;
        }
        finish(targets[n - 1]);
      });
    });
  }

  /** Cho mot cau tra loi text tu do (vd phu thuy). */
  awaitText(userID, seconds) {
    return new Promise((resolve) => {
      let done = false;
      const finish = (val) => {
        if (done) return;
        done = true;
        this.pendingDM.delete(userID);
        clearTimeout(timer);
        resolve(val);
      };
      const timer = setTimeout(() => finish(null), seconds * 1000);
      this.pendingDM.set(userID, (text) => finish(normalize(text)));
    });
  }

  // ---- Vong doi tro choi ----
  async start() {
    this.ctx.claimDM(this.players);
    await this.sendRoles();
    await this.ctx.send(
      `🌌 *MA SOI BAT DAU!* Co ${this.players.length} nguoi choi.\n` +
        `Vai tro da duoc gui RIENG cho tung nguoi. Kiem tra tin nhan cho.\n` +
        `Neu chua nhan duoc, hay nhan tin bat ky cho bot (mo hop thoai) roi bao chu phong.`
    );
    await sleep(3000);
    await this.gameLoop();
  }

  async sendRoles() {
    // Danh sach dong doi soi de bao cho nhau
    const wolves = this.players.filter((id) => this.isWolf(id));
    const wolfNames = await this.ctx.getNames(wolves);
    for (const uid of this.players) {
      const r = this.role(uid);
      let msg =
        `🎭 Vai cua ban: ${r.emoji} *${r.name}*\n` +
        `Phe: ${r.team === "soi" ? "SOI 🐺" : "DAN LANG 🏡"}\n\n` +
        `${r.desc}`;
      if (r.team === "soi" && wolves.length > 1) {
        const mates = wolves.filter((id) => id !== uid).map((id) => wolfNames[id]);
        msg += `\n\nDong doi Soi cua ban: ${mates.join(", ")}`;
      }
      await this.ctx.sendDM(uid, msg);
    }
  }

  async gameLoop() {
    while (!this.ended) {
      this.round++;
      await this.nightPhase();
      if (await this.checkEnd()) break;
      await this.dayPhase();
      if (await this.checkEnd()) break;
    }
  }

  // ================= DEM =================
  async nightPhase() {
    this.phase = "night";
    await this.ctx.send(
      `\n🌙 *DEM ${this.round} buong xuong...*\n` +
        `Ca lang nham mat. Cac vai co nang luc hay xem tin nhan RIENG tu bot.`
    );

    const deaths = new Set();
    let wolfVictim = null;
    let guardedID = null;

    // --- Buoc A: Soi, Tien tri, Bao ve hanh dong song song ---
    const tasks = [];

    // SOI
    const wolves = this.aliveWolves();
    const wolfTargets = this.aliveList().filter((id) => !this.isWolf(id));
    const wolfChoices = [];
    for (const w of wolves) {
      tasks.push(
        this.awaitChoice(
          w,
          wolfTargets,
          "🐺 DEM - Phe Soi: chon nguoi de CAN chet dem nay:",
          this.cfg.nightSeconds
        ).then((t) => {
          if (t) wolfChoices.push(t);
        })
      );
    }

    // TIEN TRI
    const seer = this.playersWithRole("TIEN_TRI")[0];
    if (seer) {
      const seerTargets = this.aliveList().filter((id) => id !== seer);
      tasks.push(
        this.awaitChoice(
          seer,
          seerTargets,
          "🔮 DEM - Tien tri: chon nguoi de SOI (kiem tra):",
          this.cfg.nightSeconds
        ).then(async (t) => {
          if (t) {
            const nm = await this.ctx.getName(t);
            const verdict = this.isWolf(t) ? "la SOI 🐺" : "KHONG phai Soi ✅";
            await this.ctx.sendDM(seer, `🔮 Ket qua: *${nm}* ${verdict}.`);
          }
        })
      );
    }

    // BAO VE
    const guard = this.playersWithRole("BAO_VE")[0];
    if (guard) {
      const gTargets = this.aliveList().filter((id) => id !== this.lastGuarded);
      tasks.push(
        this.awaitChoice(
          guard,
          gTargets,
          "🛡️ DEM - Bao ve: chon nguoi de BAO VE (khong lap 2 dem):",
          this.cfg.nightSeconds
        ).then((t) => {
          if (t) guardedID = t;
        })
      );
    }

    await Promise.all(tasks);

    // Tinh nan nhan cua Soi (nhieu phieu nhat)
    if (wolfChoices.length) {
      const tally = new Map();
      for (const t of wolfChoices) tally.set(t, (tally.get(t) || 0) + 1);
      let best = -1;
      const tops = [];
      for (const [id, c] of tally) {
        if (c > best) {
          best = c;
          tops.length = 0;
          tops.push(id);
        } else if (c === best) tops.push(id);
      }
      wolfVictim = tops[Math.floor(Math.random() * tops.length)];
    }

    this.lastGuarded = guardedID;
    if (wolfVictim && wolfVictim === guardedID) {
      wolfVictim = null; // duoc bao ve
    }

    // --- Buoc B: Phu thuy ---
    const witch = this.playersWithRole("PHU_THUY")[0];
    if (witch) {
      let info = "🧪 DEM - Phu thuy.\n";
      if (wolfVictim && !this.witchHealUsed) {
        const nm = await this.ctx.getName(wolfVictim);
        info += `Dem nay *${nm}* sap bi Soi can.\n- Go *cuu* de cuu ho (con ${this.witchHealUsed ? 0 : 1} binh cuu).\n`;
      } else if (wolfVictim) {
        info += `Co nguoi sap chet nhung ban da het binh cuu.\n`;
      } else {
        info += `Dem nay khong ai bi Soi can (hoac ban khong biet).\n`;
      }
      if (!this.witchPoisonUsed) {
        info += `- Go *doc* de dung binh DOC giet 1 nguoi.\n`;
      }
      info += `- Go *bo qua* de khong lam gi.`;
      await this.ctx.sendDM(witch, info);

      const ans = await this.awaitText(witch, this.cfg.nightSeconds);
      if (ans === "cuu" && wolfVictim && !this.witchHealUsed) {
        this.witchHealUsed = true;
        wolfVictim = null;
        await this.ctx.sendDM(witch, "✅ Ban da dung binh cuu.");
      } else if (ans === "doc" && !this.witchPoisonUsed) {
        const pTargets = this.aliveList().filter((id) => id !== witch);
        const poison = await this.awaitChoice(
          witch,
          pTargets,
          "🧪 Chon nguoi de dung binh DOC:",
          this.cfg.nightSeconds
        );
        if (poison) {
          this.witchPoisonUsed = true;
          deaths.add(poison);
          await this.ctx.sendDM(witch, "☠️ Ban da dung binh doc.");
        }
      }
    }

    if (wolfVictim) deaths.add(wolfVictim);

    // --- Sang: cong bo ---
    await this.ctx.send(`\n☀️ *TROI SANG (Ngay ${this.round})*`);
    await this.resolveDeaths([...deaths], "dem qua");
  }

  // ================= NGAY =================
  async dayPhase() {
    if (this.ended) return;
    this.phase = "day";
    const alive = this.aliveList();
    const names = await this.ctx.getNames(alive);
    await this.ctx.send(
      `💬 *THAO LUAN* (${this.cfg.daySeconds}s). Ca lang con song:\n` +
        numberedList(alive.map((id) => names[id])) +
        `\n\nHay tranh luan tim ra Soi. Sap toi luot bo phieu.`
    );
    await sleep(this.cfg.daySeconds * 1000);
    if (this.ended) return;
    await this.votePhase();
  }

  async votePhase() {
    this.phase = "vote";
    this.votes = new Map();
    this._voteAlive = this.aliveList();
    const names = await this.ctx.getNames(this._voteAlive);
    await this.ctx.send(
      `🗳️ *BO PHIEU TREO CO* (${this.cfg.voteSeconds}s)\n` +
        `Go *${this.ctx.prefix}vote <so>* de bo phieu:\n` +
        numberedList(this._voteAlive.map((id) => names[id])) +
        `\n(Go ${this.ctx.prefix}vote 0 de bo qua)`
    );
    await sleep(this.cfg.voteSeconds * 1000);
    if (this.ended) return;

    // Kiem phieu
    const tally = new Map();
    for (const target of this.votes.values()) {
      if (target === "skip") continue;
      tally.set(target, (tally.get(target) || 0) + 1);
    }
    let best = 0;
    let tops = [];
    for (const [id, c] of tally) {
      if (c > best) {
        best = c;
        tops = [id];
      } else if (c === best) tops.push(id);
    }
    this.phase = "day";

    if (best === 0 || tops.length !== 1) {
      await this.ctx.send("🤝 Khong ai bi treo co (hoa phieu hoac khong du phieu).");
      return;
    }
    const victim = tops[0];
    const nm = await this.ctx.getName(victim);
    await this.ctx.send(`🪢 Ca lang bo phieu treo co *${nm}* (${best} phieu).`);
    await this.resolveDeaths([victim], "bi treo co");
  }

  /** Nhan tin nhan nhom (chu yeu la lenh vote trong luot bo phieu). */
  async handleMessage(userID, text) {
    if (this.ended) return;
    if (this.phase !== "vote") return;
    if (!this.alive.has(userID)) return;
    const t = normalize(text);
    const pref = this.ctx.prefix + "vote";
    if (!t.startsWith(pref)) return;
    const numStr = t.slice(pref.length).trim();
    const n = parseInt(numStr, 10);
    if (isNaN(n)) return;
    if (n === 0) {
      this.votes.set(userID, "skip");
      return this.ctx.send(`${await this.ctx.getName(userID)} bo qua.`);
    }
    if (n < 1 || n > this._voteAlive.length) return;
    const target = this._voteAlive[n - 1];
    this.votes.set(userID, target);
    const vn = await this.ctx.getName(userID);
    const tn = await this.ctx.getName(target);
    await this.ctx.send(`🗳️ ${vn} -> ${tn}`);
  }

  // ---- Xu ly cai chet (bao gom Tho san ban tra) ----
  async resolveDeaths(list, cause) {
    const realDeaths = list.filter((id) => this.alive.has(id));
    if (!realDeaths.length) {
      if (cause === "dem qua") await this.ctx.send("🎉 Dem qua binh yen, khong ai chet!");
      return;
    }
    for (const uid of realDeaths) {
      this.alive.delete(uid);
      const r = this.role(uid);
      const nm = await this.ctx.getName(uid);
      await this.ctx.send(`💀 *${nm}* (${cause}) da chet. Vai tro: ${r.emoji} ${r.name}.`);

      // Tho san ban tra
      if (r.key === "THO_SAN") {
        await this.hunterShoot(uid);
      }
    }
  }

  async hunterShoot(hunterID) {
    const targets = this.aliveList();
    if (!targets.length) return;
    await this.ctx.send(
      `🏹 Tho san dang chon muc tieu ban tra... (xem DM cua tho san, ${this.cfg.nightSeconds}s)`
    );
    const shot = await this.awaitChoice(
      hunterID,
      targets,
      "🏹 Ban la Tho san va vua chet. Chon 1 nguoi de ban chet theo:",
      this.cfg.nightSeconds
    );
    if (shot && this.alive.has(shot)) {
      this.alive.delete(shot);
      const r = this.role(shot);
      const nm = await this.ctx.getName(shot);
      await this.ctx.send(`🏹💀 Tho san ban chet *${nm}*. Vai tro: ${r.emoji} ${r.name}.`);
      // Neu ban trung tho san khac -> khong lam chuoi de tranh phuc tap
    }
  }

  // ---- Kiem tra ket thuc ----
  async checkEnd() {
    const w = this.aliveWolves().length;
    const v = this.aliveVillagers().length;
    if (w === 0) {
      await this.endGame("dan");
      return true;
    }
    if (w >= v) {
      await this.endGame("soi");
      return true;
    }
    return false;
  }

  async endGame(winner) {
    if (this.ended) return;
    this.ended = true;
    this.phase = "end";
    const lines = [];
    for (const uid of this.players) {
      const r = this.role(uid);
      const nm = await this.ctx.getName(uid);
      const status = this.alive.has(uid) ? "song" : "chet";
      lines.push(`- ${nm}: ${r.emoji} ${r.name} (${status})`);
    }
    await this.ctx.send(
      `\n🏁 *KET THUC!* ` +
        (winner === "soi" ? "🐺 *PHE SOI CHIEN THANG!*" : "🏡 *PHE DAN LANG CHIEN THANG!*") +
        `\n\nBang vai tro:\n` +
        lines.join("\n")
    );
    this.ctx.releaseDM(this.players);
    this.ctx.finish();
  }

  async forceStop() {
    this.ended = true;
    this.phase = "end";
    for (const [, fn] of this.pendingDM) {
      /* de resolvers tu het gio */
    }
    this.ctx.releaseDM(this.players);
  }
}

module.exports = { MaSoiGame };
