"use strict";

const fs = require("fs");
const path = require("path");
const { getAppStateViaWeb } = require("./webLogin");

/**
 * Lop boc (wrapper) quanh thu vien FCA khong chinh thuc.
 *
 * Mac dinh dung "ws3-fca". Neu ban muon dung goi khac (vd fca-unofficial,
 * nexus-fca...) chi can `npm i <ten-goi>` roi doi bien FCA_MODULE ben duoi,
 * mien la goi do co ham login(credentials, options, callback) tuong thich.
 */
const FCA_MODULE = process.env.FCA_MODULE || "ws3-fca";

function loadFca() {
  try {
    const mod = require(FCA_MODULE);
    // Mot so ban export thang ham login, ban khac export { login }
    if (typeof mod === "function") return mod;
    if (mod && typeof mod.login === "function") return mod.login;
    if (mod && typeof mod.default === "function") return mod.default;
    throw new Error(`Goi ${FCA_MODULE} khong co ham login hop le.`);
  } catch (e) {
    console.error(
      `\n[LOI] Khong nap duoc thu vien "${FCA_MODULE}".\n` +
        `Hay chay:  npm install ${FCA_MODULE}\n` +
        `Hoac dat bien moi truong FCA_MODULE sang ten goi ban da cai.\n`
    );
    throw e;
  }
}

/**
 * Doc appstate tu file (neu chua co thi mo web cho nguoi dung dang nhap).
 */
async function resolveAppState(config, rootDir) {
  const appStatePath = path.resolve(rootDir, config.appStateFile || "appstate.json");
  if (!fs.existsSync(appStatePath)) {
    // Chua co phien dang nhap -> mo trinh duyet Facebook that de dang nhap
    console.log("Chua co appstate. Mo trinh duyet de ban dang nhap Facebook...");
    await getAppStateViaWeb(config, rootDir);
  }
  const raw = fs.readFileSync(appStatePath, "utf8");
  try {
    return JSON.parse(raw);
  } catch (e) {
    throw new Error("File appstate khong phai JSON hop le: " + e.message);
  }
}

/**
 * Dang nhap Facebook, tra ve doi tuong `api` cua FCA.
 * @param {object} config - noi dung config.json
 * @param {string} rootDir - thu muc goc du an (de tim file appstate)
 * @returns {Promise<object>} api
 */
async function login(config, rootDir) {
  const fca = loadFca();

  let credentials;
  // Cach dang nhap:
  //  - "password": dung email + mat khau trong config
  //  - mac dinh: dung appstate; neu chua co se mo web cho ban dang nhap tay
  if (config.loginMethod === "password" || (config.useAppState === false && config.email)) {
    if (!config.email || !config.password) {
      throw new Error('loginMethod="password" nhung thieu email/password trong config.json.');
    }
    credentials = { email: config.email, password: config.password };
  } else {
    const appState = await resolveAppState(config, rootDir);
    credentials = { appState };
  }

  const options = {
    listenEvents: true,
    selfListen: false,
    updatePresence: false,
    autoMarkRead: false,
    autoMarkDelivery: false,
    logLevel: "silent",
    forceLogin: true,
  };

  return new Promise((resolve, reject) => {
    fca(credentials, options, (err, api) => {
      if (err) {
        return reject(err);
      }
      // Luu lai appstate moi de lan sau khong bi dang xuat
      try {
        const out = path.resolve(rootDir, config.appStateFile || "appstate.json");
        fs.writeFileSync(out, JSON.stringify(api.getAppState(), null, 2));
      } catch (_) {
        /* khong sao neu khong ghi duoc */
      }
      api.setOptions(options);
      resolve(api);
    });
  });
}

module.exports = { login };
