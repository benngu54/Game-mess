"use strict";

/**
 * Bo nho dem ten nguoi dung de khong goi API lien tuc.
 */
class NameCache {
  constructor(api) {
    this.api = api;
    this.cache = new Map();
  }

  async get(userID) {
    if (this.cache.has(userID)) return this.cache.get(userID);
    const name = await this._fetch(userID);
    this.cache.set(userID, name);
    return name;
  }

  async getMany(userIDs) {
    const result = {};
    const missing = userIDs.filter((id) => !this.cache.has(id));
    if (missing.length) {
      const info = await this._fetchMany(missing);
      for (const id of missing) {
        const nm = (info[id] && info[id].name) || `NguoiChoi_${String(id).slice(-4)}`;
        this.cache.set(id, nm);
      }
    }
    for (const id of userIDs) result[id] = this.cache.get(id);
    return result;
  }

  _fetch(userID) {
    return this._fetchMany([userID]).then(
      (info) => (info[userID] && info[userID].name) || `NguoiChoi_${String(userID).slice(-4)}`
    );
  }

  _fetchMany(ids) {
    return new Promise((resolve) => {
      try {
        this.api.getUserInfo(ids, (err, info) => {
          if (err || !info) return resolve({});
          resolve(info);
        });
      } catch (e) {
        resolve({});
      }
    });
  }
}

module.exports = { NameCache };
