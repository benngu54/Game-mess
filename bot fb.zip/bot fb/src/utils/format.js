"use strict";

/** Bo dau tieng Viet + ve chu thuong, dung de so sanh am tiet. */
function normalize(str) {
  return String(str || "")
    .toLowerCase()
    .normalize("NFC")
    .trim()
    .replace(/\s+/g, " ");
}

/** Bo dau hoan toan (de so khop long hon neu can). */
function stripAccents(str) {
  return normalize(str)
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/đ/g, "d");
}

/** Tao danh sach danh so 1..n tu mang ten. */
function numberedList(items) {
  return items.map((it, i) => `${i + 1}. ${it}`).join("\n");
}

/** Chia mang thanh cac cum nho (dung de gui tin nhan dai). */
function chunk(arr, size) {
  const out = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

function pluralVi(n, word) {
  return `${n} ${word}`;
}

module.exports = { normalize, stripAccents, numberedList, chunk, pluralVi };
