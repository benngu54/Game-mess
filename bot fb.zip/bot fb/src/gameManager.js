"use strict";

const { NameCache } = require("./utils/names");
const { Lobby } = require("./lobby");
const { NoiTuGame } = require("./games/noiTu");
const { MaSoiGame } = require("./games/maSoi");

/**
 * Quan ly toan bo tro choi tren nhieu nhom chat.
 * Moi nhom (threadID) chi co 1 phien (sanh cho hoac van dang choi) tai 1 thoi diem.
 */
class GameManager {
  constructor(api, config) {
    this.api = api;
    this.config = config;
    this.prefix = config.prefix || "!";
    this.names = new NameCache(api);
    this.slots = new Map(); // threadID -> { kind, obj, ctx }
    this.dmOwner = new Map(); // userID -> threadID (dang trong van co DM)
  }

  isAdmin(userID) {
    const admins = this.config.admins || [];
    return admins.length === 0 ? false : admins.includes(String(userID));
  }

  makeCtx(threadID) {
    const self = this;
    return {
      threadID,
      config: this.config,
      prefix: this.prefix,
      send: (msg) => self._send(threadID, msg, false),
      sendDM: (uid, msg) => self._send(uid, msg, true),
      getName: (uid) => self.names.get(uid),
      getNames: (ids) => self.names.getMany(ids),
      isAdmin: (uid) => self.isAdmin(uid),
      claimDM: (uids) => uids.forEach((u) => self.dmOwner.set(u, threadID)),
      releaseDM: (uids) => uids.forEach((u) => self.dmOwner.delete(u)),
      finish: () => self._clearSlot(threadID),
    };
  }

  /**
   * Gui tin nhan. Ban ws3-fca nay dung Promise:
   *   sendMessage(msg, threadID, replyToMessage, isSingleUser)
   * @param {string} target - threadID nhom, hoac userID khi nhan rieng
   * @param {boolean} isSingleUser - true khi nhan RIENG cho 1 nguoi (DM)
   */
  async _send(target, msg, isSingleUser = false) {
    try {
      await this.api.sendMessage(msg, String(target), undefined, isSingleUser);
    } catch (e) {
      const detail = e && (e.errorSummary || e.errorDescription || e.error || e.message);
      console.error("[send] loi:", detail || e);
    }
  }

  _clearSlot(threadID) {
    const slot = this.slots.get(threadID);
    this.slots.delete(threadID);
    // giai phong DM owner con sot lai cua thread nay
    for (const [uid, tid] of [...this.dmOwner]) {
      if (tid === threadID) this.dmOwner.delete(uid);
    }
    return slot;
  }

  // ---------- Dinh tuyen tin nhan ----------
  async onMessage(event) {
    if (!event || event.type !== "message") return;
    const body = (event.body || "").trim();
    const senderID = event.senderID;
    const threadID = event.threadID;
    const isGroup = threadID !== senderID;

    if (isGroup) {
      await this.onGroupMessage(threadID, senderID, body);
    } else {
      await this.onDirectMessage(senderID, body);
    }
  }

  async onDirectMessage(userID, body) {
    const threadID = this.dmOwner.get(userID);
    if (!threadID) return; // khong o trong van nao co DM
    const slot = this.slots.get(threadID);
    if (slot && slot.kind === "game" && slot.obj.handleDM) {
      slot.obj.handleDM(userID, body);
    }
  }

  async onGroupMessage(threadID, senderID, body) {
    const isCmd = body.startsWith(this.prefix);
    const cmd = isCmd ? body.slice(this.prefix.length).trim().split(/\s+/)[0].toLowerCase() : "";
    const slot = this.slots.get(threadID);

    // Lenh toan cuc
    if (cmd === "help") return this.sendHelp(threadID);
    if (cmd === "stop") return this.forceStop(threadID, senderID);

    if (!slot) {
      if (cmd === "noitu") return this.startNoiTu(threadID, senderID); // choi ngay, khong can join
      if (cmd === "masoi") return this.createLobby(threadID, "masoi", senderID);
      if (cmd === "join" || cmd === "start")
        return this._send(
          threadID,
          `Chua co van nao. Go ${this.prefix}noitu (choi ngay) hoac ${this.prefix}masoi de tao van.`
        );
      return; // tin nhan thuong, bo qua
    }

    // Dang co sanh cho
    if (slot.kind === "lobby") {
      const lobby = slot.obj;
      switch (cmd) {
        case "join":
          return lobby.join(senderID);
        case "leave":
          return lobby.leave(senderID);
        case "players":
          return lobby.listPlayers();
        case "start":
          return lobby.tryStart(senderID, (type, players, host) =>
            this.launchGame(threadID, type, players, host)
          );
        case "cancel":
          return lobby.cancel(senderID);
        case "noitu":
        case "masoi":
          return this._send(threadID, "Dang co van cho san. Go " + this.prefix + "cancel de huy truoc.");
        default:
          return;
      }
    }

    // Dang trong van -> chuyen cho game
    if (slot.kind === "game") {
      if (cmd === "noitu" || cmd === "masoi") {
        return this._send(threadID, `Dang co van dang choi. Go ${this.prefix}stop de dung truoc.`);
      }
      if (slot.obj.handleMessage) await slot.obj.handleMessage(senderID, body);
    }
  }

  /** Noi Tu che do mo: choi ngay, khong can sanh cho. */
  async startNoiTu(threadID, starterID) {
    const ctx = this.makeCtx(threadID);
    const game = new NoiTuGame(ctx, starterID);
    this.slots.set(threadID, { kind: "game", obj: game, ctx });
    try {
      await game.start();
    } catch (e) {
      console.error("[noitu] loi khi bat dau:", e);
      await this._send(threadID, "⚠️ Loi khi bat dau Noi Tu.");
      this._clearSlot(threadID);
    }
  }

  async createLobby(threadID, type, hostID) {
    const ctx = this.makeCtx(threadID);
    const lobby = new Lobby(ctx, type, hostID);
    this.slots.set(threadID, { kind: "lobby", obj: lobby, ctx });
    await lobby.announceOpen();
  }

  async launchGame(threadID, type, players, hostID) {
    const ctx = this.makeCtx(threadID);
    let game;
    if (type === "masoi") game = new MaSoiGame(ctx, players);
    else return; // Noi Tu dung startNoiTu (che do mo), khong qua day

    this.slots.set(threadID, { kind: "game", obj: game, ctx });
    try {
      await game.start();
    } catch (e) {
      console.error("[game] loi khi chay:", e);
      await this._send(threadID, "⚠️ Co loi khi chay van, da dung lai.");
      if (game.forceStop) await game.forceStop();
      this._clearSlot(threadID);
    }
  }

  async forceStop(threadID, senderID) {
    const slot = this.slots.get(threadID);
    if (!slot) return this._send(threadID, "Khong co van nao dang chay.");
    const host = slot.obj.hostID;
    if (senderID !== host && !this.isAdmin(senderID)) {
      return this._send(threadID, "Chi chu phong hoac admin moi duoc dung van.");
    }
    // Noi Tu co bang xep hang khi dung
    if (typeof slot.obj.stop === "function") {
      await slot.obj.stop(); // stop() tu goi ctx.finish() de xoa slot
      return;
    }
    if (slot.obj.forceStop) await slot.obj.forceStop();
    this._clearSlot(threadID);
    await this._send(threadID, "🛑 Da dung van theo yeu cau.");
  }

  sendHelp(threadID) {
    const p = this.prefix;
    return this._send(
      threadID,
      `🤖 *BOT QUAN TRO GAME*\n\n` +
        `📝 *Noi Tu* (choi ngay, ai cung choi duoc):\n` +
        `  ${p}noitu   - bat dau noi tu\n` +
        `  (chi can go cum 2 tieng noi tiep, khong can join)\n` +
        `  ${p}stop    - ket thuc & xem bang xep hang\n\n` +
        `🐺 *Ma Soi* (can ${this.config.game.minPlayers}-${this.config.game.maxPlayers} nguoi):\n` +
        `  ${p}masoi   - mo van (tao sanh cho)\n` +
        `  ${p}join    - tham gia\n` +
        `  ${p}leave   - roi\n` +
        `  ${p}players - xem danh sach\n` +
        `  ${p}start   - chu phong bat dau (>= ${this.config.game.minPlayers} nguoi)\n` +
        `  ${p}vote <so> - bo phieu treo co\n` +
        `  ${p}cancel  - huy sanh cho\n\n` +
        `  ${p}stop    - dung van (chu phong/admin)\n` +
        `  ${p}help    - tro giup\n\n` +
        `Ma Soi se nhan RIENG vai cho tung nguoi.`
    );
  }
}

module.exports = { GameManager };
