# Bot Game Messenger — Nối Từ & Ma Sói

Bot làm **quản trò** cho hai trò chơi trong nhóm chat Facebook Messenger:

- 📝 **Nối Từ** — nối cụm từ tiếng Việt 2 tiếng theo lượt, hết giờ bị loại.
- 🐺 **Ma Sói** (Werewolf) — bot **nhắn riêng vai** cho từng người, điều hành
  đêm/ngày, bỏ phiếu treo cổ, tự tính thắng thua.

Mỗi ván cần **6–50 người**.

> ⚠️ Dùng thư viện đăng nhập không chính thức → **có nguy cơ khoá tài khoản**.
> **Hãy dùng nick phụ.** Xem [HUONG_DAN.md](HUONG_DAN.md).

## Bắt đầu nhanh

```bash
npm install
copy config.example.json config.json
npm run login    # mở trình duyệt Facebook để bạn đăng nhập tay, bot tự lấy cookie
npm start
```

Trong nhóm chat, gõ `!help`. Chi tiết cài đặt & cách chơi: **[HUONG_DAN.md](HUONG_DAN.md)**.

Mặc định đăng nhập bằng **web**: bot mở Chrome/Edge có sẵn, bạn đăng nhập bằng
tay (tự xử lý 2FA), bot lấy cookie phiên — **không cần điền mật khẩu vào config**.

## Cấu trúc dự án

```
index.js                  # điểm khởi động: đăng nhập + lắng nghe tin nhắn
config.example.json       # mẫu cấu hình
data/words.txt            # từ điển Nối Từ (chế độ strict), tự thêm được
scripts/getAppState.js    # tiện ích lấy cookie từ email/mật khẩu
src/
  bot.js                  # lớp bọc thư viện FCA (đăng nhập)
  gameManager.js          # định tuyến lệnh, quản lý ván theo từng nhóm
  lobby.js                # sảnh chờ: join/leave/start (6–50 người)
  utils/format.js         # chuẩn hoá tiếng Việt, tiện ích chuỗi
  utils/names.js          # bộ nhớ đệm tên người chơi
  games/noiTu.js          # engine Nối Từ
  games/maSoi/index.js    # engine Ma Sói (đêm/ngày/vote)
  games/maSoi/roles.js    # định nghĩa & chia vai
```

## Các vai trong Ma Sói

| Vai | Phe | Năng lực |
|-----|-----|----------|
| 🐺 Sói | Sói | Mỗi đêm cùng chọn 1 người để cắn |
| 🔮 Tiên tri | Dân | Mỗi đêm soi 1 người xem có phải Sói không |
| 🛡️ Bảo vệ | Dân | Mỗi đêm bảo vệ 1 người (không lặp 2 đêm) |
| 🧪 Phù thuỷ | Dân | 1 bình cứu + 1 bình độc (mỗi loại 1 lần/ván) |
| 🏹 Thợ săn | Dân | Khi chết được bắn chết theo 1 người |
| 🧑‍🌾 Dân làng | Dân | Suy luận và bỏ phiếu |

Số Sói ≈ 20% người chơi. Vai đặc biệt bật dần theo số người
(Tiên tri từ 6 người, Bảo vệ/Phù thuỷ từ 8, Thợ săn từ 10).

## Cấu hình (`config.json`)

- `prefix` — ký tự lệnh (mặc định `!`)
- `game.minPlayers` / `maxPlayers` — 6 / 50
- `game.noiTu.turnSeconds` — thời gian mỗi lượt Nối Từ
- `game.noiTu.strictDictionary` — bắt buộc từ có trong `data/words.txt`
- `game.maSoi.nightSeconds` / `daySeconds` / `voteSeconds` — thời gian các pha
- `admins` — danh sách UID được quyền `!stop`
