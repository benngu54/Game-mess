"use strict";

/**
 * Tien ich lay appstate (cookie) tu email + mat khau.
 * Chay: npm run getcookie
 *
 * Dieu kien: config.json phai co "email" va "password" hop le, va tai khoan
 * KHONG bat 2FA (neu bat 2FA hay dung cach export cookie bang trinh duyet,
 * xem HUONG_DAN.md).
 *
 * Sau khi chay xong se tao file appstate.json. Luc do ban co the dat
 * "useAppState": true trong config.json va xoa email/password di cho an toan.
 */

const fs = require("fs");
const path = require("path");

const ROOT = path.resolve(__dirname, "..");
const FCA_MODULE = process.env.FCA_MODULE || "ws3-fca";

function loadConfig() {
  const p = path.resolve(ROOT, "config.json");
  if (!fs.existsSync(p)) {
    console.error("Chua co config.json. Copy config.example.json va dien email/password.");
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

const config = loadConfig();
if (!config.email || !config.password) {
  console.error("config.json phai co email va password de lay appstate.");
  process.exit(1);
}

let fca;
try {
  const mod = require(FCA_MODULE);
  fca = typeof mod === "function" ? mod : mod.login || mod.default;
  if (typeof fca !== "function") throw new Error("khong co ham login");
} catch (e) {
  console.error(`Chua cai thu vien ${FCA_MODULE} (hoac loi export). Chay: npm install`);
  process.exit(1);
}

fca({ email: config.email, password: config.password }, (err, api) => {
  if (err) {
    console.error("Dang nhap that bai:", err.error || err);
    console.error("Neu tai khoan bat 2FA, hay export cookie bang trinh duyet (xem HUONG_DAN.md).");
    process.exit(1);
  }
  const out = path.resolve(ROOT, config.appStateFile || "appstate.json");
  fs.writeFileSync(out, JSON.stringify(api.getAppState(), null, 2));
  console.log("Da luu appstate vao:", out);
  console.log('Bay gio dat "useAppState": true trong config.json.');
  process.exit(0);
});
