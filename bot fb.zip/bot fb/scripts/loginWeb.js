"use strict";

/**
 * Mo trinh duyet Facebook that de dang nhap tay, roi luu appstate.json.
 * Chay:  npm run login
 *
 * Cua so Chrome/Edge se hien ra. Ban dang nhap Facebook binh thuong
 * (tu xu ly 2FA/xac minh). Xong bot tu lay cookie va luu lai.
 */

const fs = require("fs");
const path = require("path");
const { getAppStateViaWeb } = require("../src/webLogin");

const ROOT = path.resolve(__dirname, "..");

function loadConfig() {
  const p = path.resolve(ROOT, "config.json");
  if (!fs.existsSync(p)) {
    console.error("Chua co config.json. Copy config.example.json thanh config.json truoc.");
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

(async () => {
  const config = loadConfig();
  try {
    await getAppStateViaWeb(config, ROOT);
    console.log('\nXong! Bay gio chay:  npm start');
    process.exit(0);
  } catch (e) {
    console.error("\n[LOI]", e.message || e);
    process.exit(1);
  }
})();
